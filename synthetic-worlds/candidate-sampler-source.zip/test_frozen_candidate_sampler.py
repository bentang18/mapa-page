"""Approved scientific sampler invariants; no source/voltage generation."""
import copy
import hashlib
import json

import numpy as np
import pytest
from frozen_candidate_sampler import build_plan, recording_seed, validate

SEED = 'fcb9d4af2537002910d4e77059d4157e'


def test_one_view_and_split_independent_noise_after_json_roundtrip():
    plan = json.loads(json.dumps(build_plan(SEED, 2, 1)))
    checked = validate(plan)
    assert checked['recordings'] == 24
    assert checked['distinct_all_seed_streams'] == 24 * 7
    assert len({w['recordings'][0]['recording_seed_hex']['unit-noise'] for w in plan['worlds']}) == 24
    assert all(w['recordings'][0]['spatial_sigma_cells'][2] == .65 for w in plan['worlds'])


def test_recording_seed_matches_approved_canonical_hash_address():
    world = 'world/linear/00000000000000000000000000000001'
    oracle = hashlib.sha256(json.dumps(['candidate-corpus-recording1', 'unit-noise', world, 0],
                                      sort_keys=True, separators=(',', ':')).encode()).hexdigest()[:32]
    assert recording_seed(world, 'unit-noise') == oracle
    plan = build_plan(SEED, 1, 1)
    for w in plan['worlds']:
        r = w['recordings'][0]
        u = int(r['recording_seed_hex']['coverage'], 16)
        expected = 'grid125' if np.random.default_rng(u).random() < .5 else 'grid242'
        assert r['geometry_key'] == expected
        assert 1 <= r['spatial_sigma_cells'][0] <= 1.3
        assert 1 <= r['spatial_sigma_cells'][1] <= 1.3
        assert .08 <= r['added_voltage_noise_rms'] <= .2


def test_repeated_views_or_noise_and_changed_width_are_rejected():
    plan = build_plan(SEED, 1, 1)
    bad = copy.deepcopy(plan)
    bad['worlds'][0]['recordings'] *= 2
    with pytest.raises(ValueError, match='Exactly one recording'):
        validate(bad)
    bad = copy.deepcopy(plan)
    bad['worlds'][1]['recordings'][0]['recording_seed_hex']['unit-noise'] = bad['worlds'][0]['recordings'][0]['recording_seed_hex']['unit-noise']
    with pytest.raises(ValueError, match='Repeated recording'):
        validate(bad)
    bad = copy.deepcopy(plan)
    bad['worlds'][0]['recordings'][0]['spatial_sigma_cells'][2] = .25
    with pytest.raises(ValueError, match='Recording differs'):
        validate(bad)


def test_world_leakage_cannot_be_hidden_by_recording_addresses():
    plan = build_plan(SEED, 1, 1)
    a = plan['worlds'][0]
    b = next(w for w in plan['worlds'] if w['split'] == 'future_valid' and w['family'] == a['family'])
    b['core_seed_hex'], b['world_group_id'] = a['core_seed_hex'], a['world_group_id']
    with pytest.raises(ValueError, match='Repeated core stream'):
        validate(plan)


def test_extension_preserves_worlds_recordings_and_balanced_core_support():
    small, large = build_plan(SEED, 1, 1), build_plan(SEED, 2, 1)
    assert small['worlds'][:8] == large['worlds'][:8]
    assert small['worlds'][8:] == large['worlds'][16:]
    for split in ('future_train', 'future_valid'):
        rows = [w for w in small['worlds'] if w['split'] == split]
        assert sum(w['family'] == 'oscillator' for w in rows) == 2
        assert len({w['family'] for w in rows}) == 7
