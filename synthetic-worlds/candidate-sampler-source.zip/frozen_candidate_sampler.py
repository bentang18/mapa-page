"""Approved seven-core candidate sampler: metadata only, never synthesize or train.

One fresh source world -> one recording profile -> one contact mask. All crops
and possible diagnostic views stay with that world. Source draws use the audited
v13 planner; recording streams use the separately approved address namespace.
"""
import argparse
import json
from pathlib import Path

import numpy as np
from candidate_sampling_identity import digest, plan_worlds, seed_int, settings_from_seed, validate_worlds

VERSION = 'uecog-seven-core-candidate-2026-10-16'
RECORDING_VERSION = 'candidate-corpus-recording1'
PURPOSES = ('profile', 'rms', 'coverage', 'unit-noise')


def recording_seed(world_group_id, purpose):
    if purpose not in PURPOSES:
        raise ValueError('Unknown recording RNG purpose')
    return digest([RECORDING_VERSION, purpose, world_group_id, 0])[:32]


def recording_for_world(world):
    seeds = {p: recording_seed(world['world_group_id'], p) for p in PURPOSES}
    widths = settings_from_seed(seeds['profile'])['spatial_sigma_cells']
    widths[2] = .65
    rms = float(np.random.default_rng(seed_int(seeds['rms'])).uniform(.08, .2))
    coverage = 'grid125' if np.random.default_rng(seed_int(seeds['coverage'])).random() < .5 else 'grid242'
    return dict(recording_index=0, world_group_id=world['world_group_id'],
                recording_seed_hex=seeds, geometry_key=coverage,
                spatial_sigma_cells=widths, added_voltage_noise_rms=rms,
                unit_noise='Independent full-source-lattice IID standard-normal float32 stream; no noise array generated.',
                normalization='Own first24s lower median/scaled MAD, then frozen; content32..64s, G3 +/-15.')


def validate(plan):
    if plan['version'] != VERSION:
        raise ValueError('Wrong candidate version')
    source_checks = validate_worlds(plan['worlds'])
    streams = {w[k] for w in plan['worlds'] for k in ('core_seed_hex', 'renderer_seed_hex', 'recipe_seed_hex')}
    for world in plan['worlds']:
        if world['split'] not in ('future_train', 'future_valid'):
            raise ValueError('Primary corpus excludes public/qualification worlds')
        records = world.get('recordings', [])
        if len(records) != 1:
            raise ValueError('Exactly one recording per independent world is required')
        record = records[0]
        for value in record['recording_seed_hex'].values():
            seed_int(value)
            if value in streams:
                raise ValueError('Repeated recording RNG stream')
            streams.add(value)
        if record != recording_for_world(world):
            raise ValueError('Recording differs from approved deterministic sampler')
        if world['settings']['broad_gain'] != 0:
            raise ValueError('Shared HGA drive must remain disabled')
    return dict(source_checks=source_checks, recordings=len(plan['worlds']),
                distinct_all_seed_streams=len(streams), one_recording_per_world=True,
                fixed_extra_hga_sigma=.65, training=False, waveforms_generated=False)


def build_plan(plan_seed, train_blocks, valid_blocks):
    worlds = plan_worlds(plan_seed, 'future_train', train_blocks) + plan_worlds(plan_seed, 'future_valid', valid_blocks)
    for world in worlds:
        world['recordings'] = [recording_for_world(world)]
    plan = dict(version=VERSION, status='Metadata example only; not a corpus launch or training manifest.',
                plan_seed_hex=plan_seed, recording_address_version=RECORDING_VERSION,
                worlds=worlds, source_lattice_shape=[12, 23],
                effective_width_rule='Recording spatial_sigma_cells overrides the legacy unused source settings spatial_sigma_cells; HGA fixed .65.',
                world_identity_rule='All renderings, coverages and crops of one world_group_id stay in its split.',
                training=False, waveforms_generated=False)
    plan['verification'] = validate(plan)
    return plan


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan-seed-hex', required=True)
    p.add_argument('--train-blocks', type=int, required=True)
    p.add_argument('--valid-blocks', type=int, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    plan = build_plan(args.plan_seed_hex, args.train_blocks, args.valid_blocks)
    with args.output.open('x') as stream:
        stream.write(json.dumps(plan, indent=2, allow_nan=False) + '\n')
    print(json.dumps(plan['verification']))


if __name__ == '__main__':
    main()
