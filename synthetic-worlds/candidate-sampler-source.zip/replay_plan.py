import json
from pathlib import Path
from frozen_candidate_sampler import build_plan,validate
p=json.loads(Path(__file__).with_name("example-plan.json").read_text())
q=build_plan(p["plan_seed_hex"],1,1)
q["status"]=p["status"]
assert p==q
print(json.dumps(dict(exact_metadata_replay=True,**validate(q)),indent=2))
