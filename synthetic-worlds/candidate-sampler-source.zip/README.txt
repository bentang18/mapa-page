Frozen seven-core synthetic candidate, approved October16,2026.
This package only draws metadata: no waveforms, clinical data or training.
Install requirements.txt, then run python replay_plan.py to reproduce all16example addresses exactly.
frozen_candidate_sampler.py CLI accepts explicit plan seed/train blocks/valid blocks/output.
One eight-world block covers six cores once and oscillator twice. It is not an epoch.
The example count is not a proposed corpus size. Never treat repeated crops as independent worlds.
Use recording widths, not the unused legacy source-settings width fields.
Renderer implementation and audited replay fixture are distributed separately as assortment-source.zip.
The old renderer fixture deliberately shares noise for matched controls. The approved sampler uses independent recording noise.
The frozen corpus distribution has not been waveform-rendered or evaluated in a model.
