"""Persistent source world and separately observed recordings; approved diagnostic.

New observation contract: mix the complete virtual source lattice before contact
selection; then CAR/filter/STFT. No production or frozen-v11 default is changed.
The source construction body is derived from v11.1 before spatial measurement.
"""
import hashlib,json,time
import numpy as np
import torch
from scipy.ndimage import gaussian_filter,gaussian_filter1d
from candidate_sampling_identity import seed_int
from cores import CORES
from renderer import (source_drives_long,split_spectrum,spatial_voltage_recipe,features_long)
from frontend import interp_fine,delayed,normalize,CONTEXT,FS,FPS,SOURCES,filtered,SessionRobustZNormalizer


def sha_array(x):return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()


def build_source_world(core_seed_hex,renderer_seed_hex,shape,settings):
    seed=seed_int(renderer_seed_hex);duration_s=64;calibration_s=24
    entry=dict(contacts=[dict(source_row=i,source_col=j) for i in range(shape[0]) for j in range(shape[1])])
    def core(_rng,h,w):return CORES['switching'](np.random.default_rng(seed_int(core_seed_hex)),h,w,frames=80*32)
    started=time.monotonic();rng=np.random.default_rng(seed)
    N=int(duration_s*FPS);calibration_frames=int(calibration_s*FPS)
    assert calibration_s==24 and duration_s==64
    spatial=True;distinct=True;flat_hf=False;freeze_hga=False;no_harmonic=False;carrier_only=False
    gain_strength=settings['hga_gain']
    contacts=entry['contacts'];r0=min(c['source_row'] for c in contacts);c0=min(c['source_col'] for c in contacts)
    rows=np.asarray([c['source_row']-r0 for c in contacts]);cols=np.asarray([c['source_col']-c0 for c in contacts])
    h,w=int(rows.max()+1),int(cols.max()+1);c=len(contacts)
    fields,state,regime,time32,hidden,source_params=source_drives_long(rng,h,w,core=core,total_frames=int((duration_s+2*CONTEXT)*FPS),shared_weight=settings["shared_core_weight"])
    rawtime=np.arange((duration_s+2*CONTEXT)*FS)/FS-CONTEXT
    centers=CONTEXT*FS+np.arange(N)*64; frame_slice=slice(CONTEXT*FPS,(CONTEXT+duration_s)*FPS)
    sampled=fields[:,:,rows,cols]
    fine=[interp_fine(q,time32,rawtime) for q in sampled]
    exponent=float(rng.uniform(2,3.5));knee=float(rng.uniform(8,25))
    # One colored realization spans the spectrum; rhythms are added to it.
    white=rng.standard_normal((len(rawtime),h,w),dtype=np.float32)
    carrier_blur=[float(rng.uniform(.3,.75)),float(rng.uniform(.3,.75))]
    white=gaussian_filter(white,sigma=(0,*carrier_blur),mode='reflect')[:,rows,cols]
    freq=np.fft.rfftfreq(len(rawtime),1/FS)
    color=(1+(freq/knee)**2)**(-exponent/4);color[0]=0
    carrier=np.fft.irfft(np.fft.rfft(white,axis=0)*color[:,None],n=len(rawtime),axis=0).astype('f4')
    carrier/=carrier.std()+1e-8
    hidden['white_innovations_sha256']=np.asarray(hashlib.sha256(white.tobytes()).hexdigest())
    hidden['original_carrier_sha256']=np.asarray(hashlib.sha256(carrier.tobytes()).hexdigest())
    if flat_hf:
        old_high=split_spectrum(carrier)[2]
        new_high=split_spectrum(white)[2]
        new_high*=np.sqrt(np.mean(old_high.astype('f8')**2)/np.mean(new_high.astype('f8')**2))
        carrier=carrier-old_high+new_high
    del white
    base_broad=np.exp(.65*np.tanh(fine[0]))
    frequencies=[];phases=[];oscillations=[];source_amplitudes=[None]
    for j,(lo,hi) in enumerate([(4,7),(8,12),(17,28),(33,52)],1):
        center=float(rng.uniform(lo,hi));jitter=gaussian_filter1d(rng.normal(size=len(time32)),6)
        inst=center+.12*normalize(jitter)
        phase0=2*np.pi*np.cumsum(np.interp(rawtime,time32,inst))/FS
        spatial_gradient=rng.uniform(-.25,.25,2)
        spatial_phase=rows*spatial_gradient[0]+cols*spatial_gradient[1]+rng.normal(0,.08,c)
        phase=(phase0[:,None]+spatial_phase).astype('f4');phases.append(phase)
        harmonic=float(rng.uniform(0,.12)) if j==4 else 0.
        oscillations.append(np.cos(phase)+harmonic*np.cos(2*phase))
        # Distinct, burst-prone envelopes; finite shared task input remains in null.
        envelope=.12+np.logaddexp(0,1.5*fine[j]-.8)
        source_amplitudes.append(envelope.astype('f4'))
        frequencies.append({'source':SOURCES[j],'carrier_center_hz':center,'second_harmonic':harmonic,'spatial_phase_gradient':spatial_gradient.tolist()})
    nreg=int(regime.max()+1)
    regional=normalize(gaussian_filter(rng.normal(size=(h,w)),1.8))[rows,cols]
    beta_coeff=rng.uniform(-.65,.65,nreg)*settings["beta_scale"];beta_coeff[0]=0
    beta_map=beta_coeff[regime][:,None]*np.tanh(.7*regional[None,:]+.5)
    lag=int(rng.integers(0,5));beta_mod32=beta_map*np.tanh(delayed(sampled[0],lag))
    beta_mod=interp_fine(beta_mod32,time32,rawtime)
    theta_strength=float(rng.uniform(.2,.55));theta_strength=settings["theta_pac"]
    strength32=theta_strength*(.45+.55*(regime%3)/2)[:,None]*(.65+.35*np.tanh(regional))[None,:]
    strength=interp_fine(strength32,time32,rawtime)
    preferred=float(rng.uniform(-np.pi,np.pi))
    pac_gate=strength*np.cos(phases[0]-preferred)
    # Exact paired intervention: only these two terms differ between arms.
    gain_contact=np.exp(rng.normal(0,.15,c))
    source_levels=np.asarray([1.,.75,.4,.35,.22])*np.exp(rng.normal(0,.15,5))
    # Complementary spectral partition of the SAME carrier; no new random draws.
    # The intervention changes only which existing source gain drives each part.
    carrier_parts=split_spectrum(carrier)
    broad_gains=[base_broad]*3
    if distinct:
        broad_gains=[np.exp(.65*np.tanh(.25*fine[0]+np.sqrt(1-.25**2)*fine[j])) for j in [1,3]]+[base_broad]
    # Intervention preserves the same trajectory/innovations and never speeds
    # the core clock. Gain freezing is a negative control, not a proposed prior.
    if freeze_hga:
        constant=np.exp(np.log(broad_gains[2]).mean(0,keepdims=True))
        broad_gains[2]=np.broadcast_to(constant,broad_gains[2].shape).copy()
    elif gain_strength!=.65:
        broad_gains[2]=np.exp(gain_strength*np.tanh(fine[0]))
    # Weak broad, slow shared gain: an explicit population-level observation
    # prior. Its coefficient is sampled, not fitted as a biological fraction.
    coordinate=state[:,0] if state.ndim==2 else state[...,0].mean(axis=(1,2))
    slow_common=normalize(gaussian_filter1d(coordinate,8))
    common=interp_fine(slow_common[:,None],time32,rawtime)
    broad_gains[2]*=np.exp(settings['broad_gain']*np.tanh(common))
    if no_harmonic:
        oscillations[3]=np.cos(phases[3])
    if carrier_only:
        broad_gains=[np.ones_like(g) for g in broad_gains]
        source_amplitudes=[None]+[np.zeros_like(source_amplitudes[j]) for j in range(1,5)]
        pac_gate=np.zeros_like(pac_gate);beta_mod=np.zeros_like(beta_mod)
    broad_voltage=sum(g*x for g,x in zip(broad_gains,carrier_parts))
    baseline=(broad_voltage*source_levels[0]).astype('f4') if distinct else base_broad*carrier*source_levels[0]
    for j in range(1,5):baseline+=source_levels[j]*source_amplitudes[j]*oscillations[j-1]
    delta=(np.exp(pac_gate)-1)*broad_voltage*source_levels[0] if distinct else (np.exp(pac_gate)-1)*base_broad*carrier*source_levels[0]
    delta+=(np.exp(beta_mod)-1)*source_levels[3]*source_amplitudes[3]*oscillations[2]
    control=(baseline*gain_contact).astype('f4');coupled=((baseline+delta)*gain_contact).astype('f4')
    if settings['coupling_profile']=='absent':np.testing.assert_array_equal(control,coupled)
    hidden.update(state=state[frame_slice].astype('f4'),regime=regime[frame_slice],
                  component_driver=sampled[:,frame_slice].astype('f4'),
                  aperiodic_component_gain=np.stack([g[centers] for g in broad_gains]).astype('f4'),
                  theta_phase=phases[0][centers].astype('f4'),source_levels=source_levels,
                  source_site_gain=gain_contact,carrier_blur_sigma_cells=np.asarray(carrier_blur))
    params=dict(core=json.loads(str(hidden['core_parameters_json'])),source_parameters=source_params,
                aperiodic_exponent=exponent,aperiodic_knee_hz=knee,carrier_blur_sigma_cells=carrier_blur,
                oscillators=frequencies,source_voltage_levels=source_levels.tolist(),settings=settings,
                source_shape=shape,source_voltage_sha256=sha_array(coupled),source_construction='v11.1 before frequency-dependent measurement mixing; full source lattice')
    return coupled,hidden,params


def contact_indices(contacts,origin,shape):
    rows=np.array([c['source_row']-origin[0] for c in contacts]);cols=np.array([c['source_col']-origin[1] for c in contacts])
    if np.any(rows<0) or np.any(cols<0) or np.any(rows>=shape[0]) or np.any(cols>=shape[1]):raise ValueError('Contact outside persistent world')
    return rows*shape[1]+cols


def full_observation(source,unit_noise,profile,shape):
    if source.shape!=unit_noise.shape or source.shape[1]!=shape[0]*shape[1]:raise ValueError('Full source/noise axes differ')
    rows,cols=np.indices(shape)
    mixed,scales=spatial_voltage_recipe(source,rows.ravel(),cols.ravel(),profile['spatial_sigma_cells'])
    mixed+=np.float32(profile['added_voltage_noise_rms'])*unit_noise
    return mixed,scales


def observe_contacts(full,indices):
    # This is deliberately BEFORE common-average reference in filtered().
    return np.ascontiguousarray(full[:,indices])


def frontend_packet(observed):
    bins=features_long(filtered(observed),2048);packet={}
    for b,name in enumerate(['slow','mid','fast']):
        raw=bins[b];norm=SessionRobustZNormalizer().fit(raw[...,:768]);z=norm.transform(raw)
        x=raw.permute(2,0,1).numpy();y=z.permute(2,0,1).numpy();m=norm.median.numpy();s=norm.sigma.numpy()
        oracle=np.where(s>=1e-6,(x.transpose(1,2,0)-m)/np.maximum(s,1e-6),np.float32(0)).transpose(2,0,1)
        np.testing.assert_array_equal(y,oracle)
        prefix=x[:768].transpose(1,2,0);lower=np.sort(prefix,axis=-1)[...,(768-1)//2,None]
        scale=np.float32(1.4826)*np.sort(abs(prefix-lower),axis=-1)[...,(768-1)//2,None]
        np.testing.assert_array_equal(m,lower);np.testing.assert_array_equal(s,scale)
        assert np.isfinite(x).all() and x.min()>=0
        packet['raw_'+name]=x[1024:].transpose(1,2,0)
        packet['precap_'+name]=y[1024:].transpose(1,2,0)
        packet[name]=np.clip(packet['precap_'+name],-15,15)
        packet['center_'+name]=m;packet['scale_'+name]=s
    return packet
