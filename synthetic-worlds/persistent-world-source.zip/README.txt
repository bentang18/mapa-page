Persistent-world control: standalone synthetic replay

This package reproduces the four synthetic observations in the MAPA persistent-
world view. It contains no neural recordings, patient/channel identifiers, model
weights, training code or remote-data dependency. Anonymous source-tile coverage
masks are retained to reproduce the two observation geometries.

It implements ONE switching recurrent core fixture, not seven persistent cores.
The independent seven-core v11 gallery has a separate source download. This
control is experimental: it does not establish physiological fidelity or useful
pretraining, and HGA spatial dependence remains under refinement.

Python >=3.12. Install requirements.txt in your own environment, then:
    python replay.py --out /new/output/directory
Optional --save-packets also saves each full-bin packet. Without it the script
still checks every packet array and writes the twelve viewer arrays. Existing
output directories are rejected rather than overwritten. Expect roughly one
minute on a laptop; no GPU is needed. Two CPU threads are requested.

The exact 128-bit seed strings, source settings, two joint observation profiles,
source/noise hashes, coverage masks and expected array hashes are in fixture.json.
Independent per-contact/bin calibration uses the first24s, then8sbuffer, then32s
content, with8srawcontext per end. Canonical CAR/filter/magnitude STFT and frozen
median/scaled-MAD normalizer are unchanged. Visible arrays show the first16s of
content, averaging within each band. Drive is a retained simulator field in
native signed units, not voltage or a recovered neural state.

The source field, carrier and unit noise are shared across four recordings.
Frequency-dependent mixing uses the FULL source lattice, then contact selection,
then observed-contact CAR. Profiles A/B jointly vary extra spatial widths/noise.
That differs from v11's observed-contact-only mixing. Coverage is literal virtual
source-grid tiles, not certified cortical distances or a physical hardware model.

Implementation provenance: persistent_world_renderer.py is the approved v14b
control with import paths adapted to this standalone package. renderer.py copies
the portable v11 renderer plus the explicit v11.1 np.float64 scalar-factor repair.
The original v11 source archive is preserved separately. Supporting frontend and
core functions are extracted from the same local implementation. package.json
records every included source SHA256 and the original renderer SHA256.

Reproducibility is verified on the pinned dependencies and original laptop.
Different hardware/library versions may change floating-point bytes; the replay
fails clearly if a retained array differs. A checksum failure is not permission
to silently relax the checks or change the recipe.
