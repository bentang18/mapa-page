"""Replay the four published synthetic controls. No clinical data or training.

Usage: python replay.py --out /new/output/directory [--save-packets]
"""
import argparse,json,time,hashlib
from pathlib import Path
import numpy as np
import torch
from persistent_world_renderer import build_source_world,full_observation,contact_indices,observe_contacts,frontend_packet,sha_array
from candidate_sampling_identity import seed_int

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--save-packets',action='store_true');args=p.parse_args()
    torch.set_num_threads(2);cpu=time.process_time();f=json.loads(Path(__file__).with_name('fixture.json').read_text());args.out.mkdir(parents=True,exist_ok=False)
    source,state,params=build_source_world(f['core_seed_hex'],f['renderer_seed_hex'],f['source_shape'],f['source_settings'])
    assert sha_array(source)==f['expected_source_voltage_sha256']
    noise=np.random.default_rng(seed_int(f['noise_seed_hex'])).standard_normal(source.shape,dtype=np.float32)
    assert sha_array(noise)==f['expected_unit_noise_sha256'];checks=[]
    for label in ['A','B']:
        world=next(w for w in f['worlds'] if w['profile']==label);settings=world['settings']
        profile={k:settings[k] for k in ['spatial_sigma_cells','added_voltage_noise_rms']};full,scales=full_observation(source,noise,profile,f['source_shape'])
        for w in [w for w in f['worlds'] if w['profile']==label]:
            grid=next(g for g in f['grids'] if g['key']==w['geometry_key']);contacts=[dict(source_row=r+grid['origin'][0],source_col=c+grid['origin'][1]) for r,c in grid['positions']]
            idx=contact_indices(contacts,f['source_origin'],f['source_shape']);packet=frontend_packet(observe_contacts(full,idx))
            assert set(packet)==set(w['expected_packet_arrays'])
            for k,v in packet.items():
                expected=w['expected_packet_arrays'][k];assert list(v.shape)==expected['shape'] and str(v.dtype)==expected['dtype'] and sha_array(v)==expected['sha256'],(w['id'],k)
            preview=np.stack([packet[b].mean(1).T[:512] for b in ['slow','mid','fast']]).astype('<f4')
            driving=state['component_driver'][[1,3,0],1024:1536][:,:,idx].astype('<f4')
            latent=state['state'][1024:1536].reshape(512,-1);indices=np.unique(np.linspace(0,latent.shape[1]-1,min(8,latent.shape[1]),dtype=int));trace=latent[:,indices].T;trace=(trace-trace.mean(1,keepdims=True))/(trace.std(1,keepdims=True)+1e-6);trace=trace.astype('<f4')
            for field,array in [('preview',preview),('driving',driving),('trace',trace)]:
                assert list(array.shape)==w[field+'_shape'] and sha_array(array)==w[field+'_sha256'],(w['id'],field)
                array.tofile(args.out/w[field+'_file'])
            if args.save_packets:np.savez_compressed(args.out/(w['id']+'-packet.npz'),**packet)
            checks.append(dict(id=w['id'],packet_arrays_exact=len(packet),preview_drive_trace_exact=True));print(w['id'],'PASS',flush=True)
            del packet
        del full
    result=dict(status='PASS exact source/noise, all60 packet arrays and all12 preview/drive/trace arrays',records=checks,cpu_s=time.process_time()-cpu,training=False,scope=f['scope'])
    (args.out/'verification.json').write_text(json.dumps(result,indent=2)+'\n');(args.out/'source-parameters.json').write_text(json.dumps(params,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
