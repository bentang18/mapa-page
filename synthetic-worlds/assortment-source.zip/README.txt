Seven-core persistent-world comparison: standalone synthetic replay

All8 source draws and64 original/wider HGA observations are specified in
fixture.json. Six cores have one source draw; oscillator has two. Each of the
four mechanism groups has two worlds, reflecting proposed equal group weights.
This is a frozen comparison fixture, NOT final recipe adoption or a corpus size.
No neural recordings, patient/channel IDs, model weights or training included.
Anonymous source-grid masks reproduce the two observation geometries.

Python>=3.12; install requirements.txt, then:
  python replay.py --out /new/output/directory
Default smoke replays8 complete sources and16 full-bin packets: profileA, wider
HGA, both coverages, every world. Approximately2–4CPU minutes on original laptop.
  python replay.py --mode full --out /new/output/directory
Full mode checks64 packets, approximately10CPU minutes. --mode sources checks
only8 complete80s source-voltage/driver/noise realizations. The script writes
verification.json, not gigabytes of duplicate recordings. Existing output
directories are rejected. Two CPU threads; no GPU, remote data or training.

Exact128bit seeds, source parameters, profiles, masks and full-bin hashes are
serialized. Full-source mixing precedes selection, observed-contact CAR,
canonical filters and periodic-Hann STFT. Prefix24s median/scaledMAD fits stay
frozen through8sbuffer and32scontent;8srawcontext perend. All7/6/7bins cached32Hz;
model pointselection4/16/32Hz. Viewer band means show first16s of content.

Original extra HGA widthU[.25,.65]. Wider: same source/profile/noise, extra HGA
width .65. Other neural/recording parameters unchanged; carrier source blur
remains independently variable. Profiles A/B share the source AND unit-noise
realization for controlled comparison. Future independent-recording noise is a
separate decision; these paired controls are not a finalized corpus sampler.

Wider mixing improves adjacent HGA dependence in all32 paired recordings but
retains weak distant dependence and some overly fast worlds. No physiological
fidelity, useful representations, speech semantics or transfer established.
Source tiles are not certified cortical distances or hardware units.

persistent_family_renderer_v18.py adds explicit family dispatch to the approved
one-core persistent builder; original switching source/hidden replay is bitwise.
Core/frontend functions are the earlier portable v11 functions. renderer.py has
the explicit v11.1 float64 spatial-factor repair; original v11 archive unchanged.
package.json lists source hashes and independent portable replay scope.

Exact checks are pinned to original numerical environment. Other hardware or
versions may differ in bytes; the script fails clearly. Never silently relax
checks or change the scientific recipe after a mismatch.
