"""Replay all8 synthetic sources and16 packets by default. No data or training.
--mode full checks64 packets; --mode sources checks only8 sources.
"""
import argparse,json,time
from pathlib import Path
import numpy as np
import torch
from persistent_family_renderer_v18 import build_source_world,full_observation,contact_indices,observe_contacts,frontend_packet,sha_array
from candidate_sampling_identity import seed_int

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--mode',choices=['sources','smoke','full'],default='smoke');args=p.parse_args();args.out.mkdir(parents=True,exist_ok=False);torch.set_num_threads(2);cpu=time.process_time();f=json.loads(Path(__file__).with_name('fixture.json').read_text());checked=[];packets=0;arrays=0
 for world in f['worlds']:
  records=[r for r in f['records'] if r['world_id']==world['world_id']];parameters=world['source_parameters'];source,state,params=build_source_world(world['core_seed_hex'],world['renderer_seed_hex'],[12,23],parameters['settings'],family=world['family']);assert sha_array(source)==records[0]['source_voltage_sha256'];assert sha_array(state['component_driver'])==records[0]['driver_sha256']
  noise=np.random.default_rng(seed_int(world['noise_seed_hex'])).standard_normal(source.shape,dtype=np.float32);assert sha_array(noise)==records[0]['unit_noise_sha256']
  if args.mode=='smoke':records=[r for r in records if r['profile']=='A' and r['arm']=='wider']
  if args.mode=='sources':records=[]
  for profile in ['A','B']:
   for arm in ['original','wider']:
    rows=[r for r in records if r['profile']==profile and r['arm']==arm]
    if not rows:continue
    settings=rows[0]['settings'];applied={k:settings[k] for k in ['spatial_sigma_cells','added_voltage_noise_rms']};full,_=full_observation(source,noise,applied,[12,23])
    for r in rows:
     grid=next(g for g in f['grids'] if g['key']==r['geometry_key']);contacts=[dict(source_row=y+grid['origin'][0],source_col=x+grid['origin'][1]) for y,x in grid['positions']];idx=contact_indices(contacts,[0,0],[12,23]);packet=frontend_packet(observe_contacts(full,idx));assert set(packet)==set(r['expected_packet_arrays'])
     for k,v in packet.items():
      expected=r['expected_packet_arrays'][k];assert list(v.shape)==expected['shape'] and str(v.dtype)==expected['dtype'] and sha_array(v)==expected['sha256'],(r['id'],k);arrays+=1
     preview=np.stack([packet[b].mean(1).T[:512] for b in ['slow','mid','fast']]).astype('<f4');driver=state['component_driver'][[1,3,0],1024:1536][:,:,idx].astype('<f4');assert sha_array(preview)==r['preview_sha256'] and sha_array(driver)==r['driving_sha256'];packets+=1;del packet
    del full
  checked.append(dict(world=world['world_id'],family=world['family'],source_and_driver_noise_exact=True));print(world['family'],world['world_id'],'PASS',round(time.process_time()-cpu,1),'CPU s',flush=True);del source,noise,state
 result=dict(mode=args.mode,source_worlds=len(checked),core_families=len({w['family'] for w in checked}),packet_records=packets,packet_arrays_exact=arrays,records=checked,cpu_s=time.process_time()-cpu,training=False,scope='Exact synthetic diagnostic replay; final recipe not adopted.')
 (args.out/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
