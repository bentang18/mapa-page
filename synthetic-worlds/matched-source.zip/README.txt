Extended matched-grid display, synthetic replay only.
Install requirements.txt and run python replay.py --output receipt.json.
Default verifies one source world and all7contact masks/105full-bin packet arrays.
The optional --full path replays all112cells and is not the default verification claim.
No real neural recording arrays or private identifier mapping are included.
Viewer geometry is12x34; frozen training candidate remains12x23/two masks.
