"""Replay one synthetic source and all seven profile-A masks by default.
--full replays all112cells. No clinical recording payload or training.
"""
import argparse,json,time
from pathlib import Path
import numpy as np
import torch
from persistent_family_renderer_v18 import build_source_world,full_observation,contact_indices,observe_contacts,frontend_packet,sha_array
from candidate_sampling_identity import seed_int
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--full',action='store_true');a=p.parse_args();assert not a.output.exists();torch.set_num_threads(2);cpu=time.process_time();f=json.loads(Path(__file__).with_name('fixture.json').read_text());worlds=f['worlds'] if a.full else f['worlds'][:1];count=0;arrays=0
 for w in worlds:
  source,state,params=build_source_world(w['core_seed_hex'],w['renderer_seed_hex'],f['source_shape'],w['source_parameters']['settings'],family=w['family']);assert sha_array(source)==w['source_sha256'];noise=np.random.default_rng(seed_int(w['noise_seed_hex'])).standard_normal(source.shape,dtype=np.float32);assert sha_array(noise)==w['unit_noise_sha256']
  rows=[r for r in f['records'] if r['world_id']==w['world_id'] and (a.full or r['profile']=='A')]
  for label in ['A','B']:
   group=[r for r in rows if r['profile']==label]
   if not group:continue
   full,_=full_observation(source,noise,group[0]['applied_profile'],f['source_shape'])
   for r in group:
    g=next(g for g in f['grids'] if g['key']==r['geometry_key']);contacts=[dict(source_row=y+g['origin'][0],source_col=x+g['origin'][1]) for y,x in g['positions']];idx=contact_indices(contacts,[0,0],f['source_shape']);packet=frontend_packet(observe_contacts(full,idx));assert set(packet)==set(r['expected_packet_arrays'])
    for key,value in packet.items():
     expected=r['expected_packet_arrays'][key];assert list(value.shape)==expected['shape'] and str(value.dtype)==expected['dtype'] and sha_array(value)==expected['sha256'],(r['id'],key);arrays+=1
    preview=np.stack([packet[b].mean(1).T[:512] for b in ['slow','mid','fast']]).astype('<f4');driver=state['component_driver'][[1,3,0],1024:1536][:,:,idx].astype('<f4');assert sha_array(preview)==r['preview_sha256'] and sha_array(driver)==r['driving_sha256'];count+=1;print(r['id'],'PASS',flush=True)
 result=dict(source_worlds=len(worlds),masks=7,packet_records=count,packet_arrays_exact=arrays,cpu_s=time.process_time()-cpu,full=a.full,training=False,scope='Exact synthetic source/frontend/display replay; no clinical payloads and no transfer claim.');a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
